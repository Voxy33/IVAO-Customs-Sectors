Guide d'installation du secteur CRNA Sud-Ouest

1. Placer le dossier ERATO complet dans Aurora/Sectorfiles/France
2. Placer les fichiers .isc/.clr/.cpr dans leurs dossiers respectifs
3. Ouvrir le profile CRNA SO - Complet (coulrus et secteurs devraient s'ouvrir automatiquement)

!!! Ne pas tenir compte des fichiers .DS_Store ou autre ils sont inutiles et causés par la compression !!!